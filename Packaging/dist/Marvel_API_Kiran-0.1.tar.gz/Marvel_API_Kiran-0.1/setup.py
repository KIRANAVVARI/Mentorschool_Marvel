import setuptools
from setuptools import setup

setup(
    name='Marvel_API_Kiran',
    version='0.1',
    description='Get data of characters in marvel in dataframe by taking API',
    author='Kiran',
    packages=['Marvel_API_Case'],
    install_requires = []
)